package com.example.examen2p_appsmov_g4;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
